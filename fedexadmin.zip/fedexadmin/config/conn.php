<?php
// === ENABLE FULL ERROR REPORTING === //
error_reporting(E_ALL);              // Report all PHP errors
ini_set('display_errors', 1);        // Display errors on screen (only for development)
ini_set('display_startup_errors', 1); // Show startup errors

// Optional: log errors to a file instead of displaying
ini_set('log_errors', 1);
ini_set('error_log', __DIR__ . '/error_log.txt'); // Store logs in the project directory

// Secure output for production (disable display, keep logging)
if ($_SERVER['SERVER_NAME'] !== 'localhost') {
    ini_set('display_errors', 0);
}


// Secure MySQLi connection

$servername = "localhost";
$username = "mjibeaut_ecom56";
$password = "L.m2~yDCPwLN#s]R";
$dbname = "mjibeaut_ecom56";

$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Database connection failed: " . htmlspecialchars($conn->connect_error));
}

// Force UTF-8
$conn->set_charset("utf8mb4");
?>
<link rel="stylesheet" href="assets/css/style.css">
<!-- JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="assets/js/app.js"></script>
