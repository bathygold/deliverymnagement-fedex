document.addEventListener("DOMContentLoaded", function() {
  const sidebar = document.getElementById("sidebar");
  const toggleBtn = document.getElementById("toggleSidebar");
  const selectAll = document.getElementById("selectAll");
  const pushBtn = document.getElementById("pushSelected");
  const rowCheckboxes = document.querySelectorAll(".rowCheckbox");
  const pushButtons = document.querySelectorAll(".pushBtn");

  // === SIDEBAR TOGGLE ===
  if (toggleBtn) {
    toggleBtn.addEventListener("click", () => {
      sidebar.classList.toggle("collapsed");
    });
  }

  // === MOBILE MENU ===
  if (window.innerWidth <= 768) {
    const mobileMenuButton = document.createElement("button");
    mobileMenuButton.textContent = "☰ Menu";
    mobileMenuButton.classList.add("btn", "gold");
    mobileMenuButton.style.margin = "1rem";
    mobileMenuButton.addEventListener("click", () => {
      sidebar.classList.toggle("open");
    });
    document.querySelector(".topbar").prepend(mobileMenuButton);
  }

  // === SELECT ALL CHECKBOXES ===
  if (selectAll) {
    selectAll.addEventListener("change", (e) => {
      rowCheckboxes.forEach(cb => cb.checked = e.target.checked);
    });
  }

  // === PUSH SELECTED ===
  if (pushBtn) {
    pushBtn.addEventListener("click", async () => {
      const selected = Array.from(rowCheckboxes)
        .filter(cb => cb.checked)
        .map(cb => cb.value);

      if (selected.length === 0) {
        alert("Please select at least one shipment.");
        return;
      }

      pushBtn.disabled = true;
      pushBtn.textContent = "Processing...";

      const formData = new FormData();
      formData.append("ids", selected.join(","));

      try {
        const res = await fetch("push.php", {
          method: "POST",
          body: formData
        });
        const data = await res.json();

        if (data.results) {
          Object.entries(data.results).forEach(([id, result]) => {
            const row = document.querySelector(`tr[data-id="${id}"]`);
            const statusCell = row.querySelector(".status-cell");
            if (result.success) {
              statusCell.textContent = "pushed";
              row.style.backgroundColor = "#e9f9e9";
            } else {
              statusCell.textContent = "error";
              row.style.backgroundColor = "#ffe6e6";
            }
          });
          alert("Push completed!");
        } else {
          alert("Unexpected response from server.");
        }
      } catch (err) {
        console.error(err);
        alert("An error occurred while pushing shipments.");
      } finally {
        pushBtn.disabled = false;
        pushBtn.textContent = "Push Selected";
      }
    });
  }

  // === INDIVIDUAL PUSH BUTTON ===
  pushButtons.forEach(btn => {
    btn.addEventListener("click", async () => {
      const id = btn.getAttribute("data-id");
      btn.disabled = true;
      btn.textContent = "Pushing...";
      const formData = new FormData();
      formData.append("ids", id);

      try {
        const res = await fetch("push.php", { method: "POST", body: formData });
        const data = await res.json();

        if (data.results && data.results[id] && data.results[id].success) {
          const row = document.querySelector(`tr[data-id="${id}"]`);
          row.querySelector(".status-cell").textContent = "pushed";
          row.style.backgroundColor = "#e9f9e9";
        } else {
          alert("Failed to push shipment ID " + id);
        }
      } catch (err) {
        console.error(err);
        alert("Error pushing shipment " + id);
      } finally {
        btn.disabled = false;
        btn.textContent = "Push";
      }
    });
  });
});
